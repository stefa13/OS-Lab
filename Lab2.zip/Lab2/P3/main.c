#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main() {
	int n, i;
	char** c;
	char* aux;
	int ok = 0;

	scanf("%d", &n);
	c = (char**) malloc(n * sizeof(char*));
	for( i = 0; i < n; ++i) {
		c[i] = (char*) malloc(20 * sizeof(char));
		scanf("%s", c[i]);
	}	
	while(ok == 0) {
		ok = 1;
		for (i = 0; i < n - 1; ++i) {
				if(strcmp(c[i], c[i+1]) > 0) {
					aux =  c[i];
					c[i] = c[i+1];
					c[i+1] = aux;
					ok = 0;
				}
			}	
	}
	for( i = 0; i<n; ++i) {
		printf("%s\n", c[i]);
		free(c[i]);
	}
	free(c);
return 0;

}
