#include <stdlib.h>
#include <stdio.h>

int main()
{
	int n,i,j, nr = 1;
	int** m;
	scanf("%d", &n);
	m = (int**) malloc(n * sizeof(int*));
	for( i = 0; i < n; ++i) {
		m[i] = (int*) malloc(n * sizeof(int));
		for( j = 0; j < n; ++j) {
			m[i][j] = nr;
			nr++;
		}
	}
	for ( i = 0; i < n; ++i) {
		nr = 0;
		for ( j = 0; j < n; ++j) {
			if( m[j][i] % 2 !=0) {
				nr+=m[j][i];
			}
		}
		printf("%d\n", nr);
	}
	for(i = 0; i < n; ++i) {
		free(m[i]);
	}
	free(m);



return 0;
}
