#include<stdlib.h>
#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include<errno.h>
int main() {
	int i,n,p,pi[2],sum=0;
	scanf("%d",&n);
	int v[n];
	for (i=1; i<=n; ++i) {
		v[i]=i;
	}
	pipe(pi);
	p = fork();
	if ( p == -1) {
		perror("Fork failed!");
		exit(1);
	}
	if ( p == 0 ) {
		close(pi[0]);
		for (i = 1; i<=n; i+=2) {
			sum+=v[i];
		}
		printf("Sum of the child: %d\n",sum);

		write(pi[1],&sum,sizeof(int));
		close(pi[1]);
		exit(0);
	}
	if ( p > 0) {
		close(pi[1]);
		read(pi[0],&sum,sizeof(int));
		close(pi[0]);
		for (i = 2; i<=n; i+=2) {
			sum+=v[i];
		}
		printf("Sum of the parent: %d\n",sum);
		wait(0);
	}
	printf("Sum: %d\n",sum);
return 0;
}
