#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>

void spawnProcessesWhilePidIsEvenIteratively() {
	while (1) {
		int pid = fork();
		if (pid == 0) {
			exit(0);
		} else {
			if (pid % 2 != 0) {
				break;
			}
			wait(0);
		}
	}
}

void spawnProcessesWhilePidIsEvenRecursively() {
	int pid = fork();
	if (pid == 0) {
		exit(0);
	}
	wait(0);
	if (pid % 2 == 0) {
		spawnProcessesWhilePidIsEvenRecursively();
	}
}

int main() {
	spawnProcessesWhilePidIsEvenRecursively();
}
