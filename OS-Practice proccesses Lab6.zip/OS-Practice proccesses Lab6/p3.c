#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
int main() {

	char* tokens[128];
	char* input=NULL;
	size_t len=0;
	int l=0;
	getline(&input,&len,stdin);
	input[strlen(input)-1] = 0;
	char *p;
	p = strtok(input, " ");
	while(p!=NULL) {
		tokens[l++] = p;
		p = strtok(NULL, " ");
	}
	tokens[l]=NULL;
	for (int i=0; i<l;++i) {
		printf("%s\n", tokens[i]);
	}
	
	int pid = fork();
	if (pid == 0) {
		execvp(tokens[0],tokens);
		printf("Failed!\n");
		exit(0);
	}
	free(input);
}
