#include<stdlib.h>
#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include<errno.h>
int main() {
	int n,i,p;
	scanf("%d",&n);
	for (i = 1; i<=n; ++i) {
		p = fork();
		if ( p == -1 ) {
			perror("Fork failed!");
			exit(1);
		}
		if ( p == 0 ) {
			if (i < 2)
				exit(1);
			if ( i==2)
				exit(0);
			if (i %2 == 0)
				exit(1);
			for (int k = 3; k*k<=i; k +=2) {
				if (i%k==0) 
					exit(1);
			}
			exit(0);
		}
			int status;
			wait(&status);
			int result = WEXITSTATUS(status);
			if ( result == 0 )
				printf("%d\n",i);
		
	}
return 0;
}
