#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
int main () {
int i=-1, j=-1, k=-1;

i = fork();
printf("Hi!  ");
if ((j = fork())) {
	printf("Hello!  ");
    k = fork();
	printf("Bye!  ");

}

printf("%d %d %d %d %d\n", i, j, k, getpid(), getppid());
}
