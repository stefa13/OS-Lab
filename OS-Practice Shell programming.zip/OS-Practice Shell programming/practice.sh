#!/bin/bash

for file in $*; do
	grep -io "\b[a-z]\+\b" $file
done|sort|uniq -c|sort -r -n -k1|awk '{ print $2}'

