#!/bin/bash

sum=0
cnt=0

files=`find dir -type f`
for current_file in $files
do
	if file "$current_file" | grep -q "ASCII text" ; then
		lines=`cat $current_file | wc -l`
		sum=$(($sum+$lines))
		cnt=$(($cnt+1))
	fi
done

echo "$sum"
echo "$cnt"

echo "$(($sum/$cnt))"
