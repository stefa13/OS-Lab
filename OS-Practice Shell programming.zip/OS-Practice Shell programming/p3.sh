#!/bin/bash

files=`find dir | grep "log$"`

for file in $files
do
	sort $file
	newfile=$file
	rm $file
	mv $newfile $file
	`cat $file`
	echo Another file!!!!
done

