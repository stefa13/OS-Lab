#!/bin/bash

for param in $@;do
	if [ -f $param ];then
		chars=`cat $param | wc --chars`
		lines=`cat $param | wc -l`
		echo "name: $param CharsNO: $chars LinesNo: $lines"
	else
		if [ -d $param ];then
			files=`find $param | wc -l`
			echo "name: $param NoOfFiles: $files"
		fi
	fi
done
