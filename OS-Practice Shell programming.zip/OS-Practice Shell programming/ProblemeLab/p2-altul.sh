#!/bin/bash

dir=$1
files=`find $dir -type f`
for file in $files;do
	if `cat $file | grep -q "[0-9]\{4,\}"`;then
		echo "$file"
	fi
done
