#!/bin/bash

steps=$#
while [ $steps -gt 0 ];do
	file=$1
	shift
	lines=`cat $file | sort | uniq -c | sort -r -n -k1 | awk '{print $2}'`
	echo "$lines"
	echo "Another file!!!"
steps=$(($steps-1))
done
