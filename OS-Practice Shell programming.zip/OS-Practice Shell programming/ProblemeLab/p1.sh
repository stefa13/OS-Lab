#!/bin/bash

sum=0
count=0
dir=$1

files=`find $dir`
for file in $files;do
	if file "$file" | grep -q "ASCII text";then
		lines=`cat "$file" | wc -l`
		sum=$(($sum+$lines))
		count=$(($count+1))
	fi
done
echo "sum: $sum ; count: $count ; average: $(($sum/$count))" 
