#!/bin/bash
files=`find -type f`
for fil in $files;do
	if file "$fil" | grep -q "ASCII text";then
		lines=`cat "$fil" | wc -l`
		if [ $lines -ge 10 ];then 
			head --lines=5 "$fil"
			tail --lines=5 "$fil"
		else
			echo "$fil"
		fi
	fi
	echo Another file!!!!!!
done
