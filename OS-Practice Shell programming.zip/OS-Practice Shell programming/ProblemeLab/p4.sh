#!/bin/bash

files=`find -type f -perm 777`

for file in $files;do
	ext=".all"
	new_name="$file$ext"
	echo "$new_name"
done
