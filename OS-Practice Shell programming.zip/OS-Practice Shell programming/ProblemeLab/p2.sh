#!/bin/bash

files=`find -type f`
for file in $files;do
	numbers=`grep -o "\<[0-9]\+\>" $file`
	for number in $numbers;do
		if echo $number | grep -q "^[0-9]\+$";then
			if [ $number -gt 999 ];then
				echo "$file"
				break
			fi
		fi
	done
done
