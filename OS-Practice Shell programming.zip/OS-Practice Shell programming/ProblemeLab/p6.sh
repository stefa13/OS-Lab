#!/bin/bash
args=$#
steps=$(($args/3))
while [ $steps -gt 0 ];do
	file=$1
	shift
	word=$1
	shift
	k=$1
	shift
	cat $file | while read line;do
		if [ `echo $line | grep -o "\<$word\>" | wc -l` -eq $k ];then
				echo "$line"
		fi
		done 
steps=$(($steps-1))
done

