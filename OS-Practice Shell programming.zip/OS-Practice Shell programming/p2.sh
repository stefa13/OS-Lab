#!/bin/bash

files=`find dir | grep "\.c$"`
count=0
for file in $files
do
	lines=`cat $file | wc -l`
	if [ $lines -gt 500 ];then
		count=`expr $count + 1`
		if [ $count -lt 3 ];then
			echo "$file"
		fi
	fi
done
