#!/bin/bash

if [ $# -ne 1 ]; then
	echo "Expected a single argument."
	exit
fi

if [ ! -d $1 ]; then
	echo "The argument should be a directory."
	exit
fi

DIR=$1

files=`find $DIR | grep "\.c$"`

count=0

for file in $files
do
	if [ `cat $file | wc -l` -gt 500 ]; then
		count=$((count + 1))
		echo $file
		if [ $count -eq 2 ]; then
			break
		fi
	fi
done

