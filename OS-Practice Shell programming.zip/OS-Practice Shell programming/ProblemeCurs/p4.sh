#!/bin/bash

files=`find .`

for file in $files; do
	if [ -L $file ]; then
		if [ ! -e $file ]; then
			echo $file
		fi
	fi
done
