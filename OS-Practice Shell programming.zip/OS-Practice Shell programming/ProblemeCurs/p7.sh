#!/bin/bash

s=""

for username in `cat users.data`; do
	s+="$username@scs.ubbcluj.ro,"
done

echo $s | sed "s/,$//"
