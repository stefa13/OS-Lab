#!/bin/bash

checksums=`find . -type f | while read f; do md5sum $f; done | awk '{print $1}' | sort | uniq`

for checksum in $checksums
do
	# echo $checksum
	if [ `find . -type f | while read f; do md5sum $f; done | grep "$checksum" | wc -l` -gt 1 ]; then
		echo `find . -type f | while read f; do md5sum $f; done | grep "$checksum" | awk '{print $2}' | sort | uniq`
	fi
done
