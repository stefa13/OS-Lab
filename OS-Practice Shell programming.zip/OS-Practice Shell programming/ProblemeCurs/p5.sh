#!/bin/bash

while true; do
	for pname in $@; do
		# echo $pname
		pids=`ps | grep "$pname" | awk '{print $1}'`
		for pid in $pids; do
			kill $pid
			echo "Terminated dangerous process $pname with PID $pid"
		done
	done
done
