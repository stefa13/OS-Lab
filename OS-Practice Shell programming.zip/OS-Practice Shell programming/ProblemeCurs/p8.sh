#!/bin/bash

cat df.fake | sed "s/[%M]//g" | awk 'NF == 6 && ($4 < 1000 || $5 > 80) {print $6}'
