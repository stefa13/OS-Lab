#!/bin/bash

logs=`find . | grep "\.log$"`

for log in $logs; do
	lines=`cat $log | sort`
	echo "$lines" > $log
done
