#!/bin/bash

# users=`cat who.fake | awk '{print $1}'`

# for user in $users; do
#	echo "$user `cat ps.fake | grep "^$user " | wc -l`"
# done

cat who.fake | awk '{print $1}' | while read user; do echo "$user `cat ps.fake | grep "^$user " | wc -l`"; done
