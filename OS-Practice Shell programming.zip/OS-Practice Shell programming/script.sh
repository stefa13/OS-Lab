#!/bin/bash

 cat passwd.fake | sed "s/[:\/]/ /g" | awk '$6 == "Dan" && $1 ~ /[02468]$/ {print}' | awk '{print $9}' | sort | uniq | wc -l
